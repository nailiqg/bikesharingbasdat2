--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY bikesharing.voucher DROP CONSTRAINT voucher_no_kartu_anggota_fkey;
ALTER TABLE ONLY bikesharing.transaksi DROP CONSTRAINT transaksi_no_kartu_anggota_fkey;
ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman DROP CONSTRAINT transaksi_khusus_peminjaman_no_kartu_peminjam_fkey;
ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman DROP CONSTRAINT transaksi_khusus_peminjaman_no_kartu_anggota_fkey;
ALTER TABLE ONLY bikesharing.sepeda DROP CONSTRAINT sepeda_no_kartu_penyumbang_fkey;
ALTER TABLE ONLY bikesharing.sepeda DROP CONSTRAINT sepeda_id_stasiun_fkey;
ALTER TABLE ONLY bikesharing.petugas DROP CONSTRAINT petugas_ktp_fkey;
ALTER TABLE ONLY bikesharing.penugasan DROP CONSTRAINT penugasan_ktp_fkey;
ALTER TABLE ONLY bikesharing.penugasan DROP CONSTRAINT penugasan_id_stasiun_fkey;
ALTER TABLE ONLY bikesharing.peminjaman DROP CONSTRAINT peminjaman_nomor_sepeda_fkey;
ALTER TABLE ONLY bikesharing.peminjaman DROP CONSTRAINT peminjaman_no_kartu_anggota_fkey;
ALTER TABLE ONLY bikesharing.peminjaman DROP CONSTRAINT peminjaman_id_stasiun_fkey;
ALTER TABLE ONLY bikesharing.laporan DROP CONSTRAINT laporan_no_kartu_anggota_fkey;
ALTER TABLE ONLY bikesharing.anggota DROP CONSTRAINT anggota_ktp_fkey;
ALTER TABLE ONLY bikesharing.acara_stasiun DROP CONSTRAINT acara_stasiun_id_stasiun_fkey;
ALTER TABLE ONLY bikesharing.acara_stasiun DROP CONSTRAINT acara_stasiun_id_acara_fkey;
ALTER TABLE ONLY bikesharing.voucher DROP CONSTRAINT voucher_pkey;
ALTER TABLE ONLY bikesharing.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman DROP CONSTRAINT transaksi_khusus_peminjaman_pkey;
ALTER TABLE ONLY bikesharing.stasiun DROP CONSTRAINT stasiun_pkey;
ALTER TABLE ONLY bikesharing.sepeda DROP CONSTRAINT sepeda_pkey;
ALTER TABLE ONLY bikesharing.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY bikesharing.person DROP CONSTRAINT person_pkey;
ALTER TABLE ONLY bikesharing.person DROP CONSTRAINT person_email_key;
ALTER TABLE ONLY bikesharing.penugasan DROP CONSTRAINT penugasan_pkey;
ALTER TABLE ONLY bikesharing.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY bikesharing.laporan DROP CONSTRAINT laporan_pkey;
ALTER TABLE ONLY bikesharing.anggota DROP CONSTRAINT anggota_pkey;
ALTER TABLE ONLY bikesharing.acara_stasiun DROP CONSTRAINT acara_stasiun_pkey;
ALTER TABLE ONLY bikesharing.acara DROP CONSTRAINT acara_pkey;
DROP TABLE bikesharing.voucher;
DROP TABLE bikesharing.transaksi_khusus_peminjaman;
DROP TABLE bikesharing.transaksi;
DROP TABLE bikesharing.stasiun;
DROP TABLE bikesharing.sepeda;
DROP TABLE bikesharing.petugas;
DROP TABLE bikesharing.person;
DROP TABLE bikesharing.penugasan;
DROP TABLE bikesharing.peminjaman;
DROP TABLE bikesharing.laporan;
DROP TABLE bikesharing.anggota;
DROP TABLE bikesharing.acara_stasiun;
DROP TABLE bikesharing.acara;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA bikesharing;
--
-- Name: bikesharing; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA bikesharing;


ALTER SCHEMA bikesharing OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acara; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.acara (
    id_acara character varying(10) NOT NULL,
    judul character varying(100) NOT NULL,
    deskripsi text,
    tgl_mulai date NOT NULL,
    tgl_akhir date NOT NULL,
    is_free boolean NOT NULL
);


ALTER TABLE bikesharing.acara OWNER TO postgres;

--
-- Name: acara_stasiun; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.acara_stasiun (
    id_stasiun character varying(10) NOT NULL,
    id_acara character varying(10) NOT NULL
);


ALTER TABLE bikesharing.acara_stasiun OWNER TO postgres;

--
-- Name: anggota; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.anggota (
    no_kartu character varying(10) NOT NULL,
    saldo real,
    points integer,
    ktp character varying(20) NOT NULL
);


ALTER TABLE bikesharing.anggota OWNER TO postgres;

--
-- Name: laporan; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.laporan (
    id_laporan character varying(10) NOT NULL,
    no_kartu_anggota character varying(10) NOT NULL,
    datetime_pinjam timestamp without time zone NOT NULL,
    nomor_sepeda character varying(10) NOT NULL,
    id_stasiun character varying(10) NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE bikesharing.laporan OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.peminjaman (
    no_kartu_anggota character varying(10) NOT NULL,
    datetime_pinjam timestamp without time zone NOT NULL,
    nomor_sepeda character varying(10) NOT NULL,
    id_stasiun character varying(10) NOT NULL,
    datetime_kembali timestamp without time zone,
    biaya real,
    denda real
);


ALTER TABLE bikesharing.peminjaman OWNER TO postgres;

--
-- Name: penugasan; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.penugasan (
    ktp character varying(20) NOT NULL,
    start_datetime timestamp without time zone NOT NULL,
    id_stasiun character varying(10) NOT NULL,
    end_datetime timestamp without time zone NOT NULL
);


ALTER TABLE bikesharing.penugasan OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.person (
    ktp character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    alamat text,
    tgl_lahir date NOT NULL,
    no_telp character varying(20)
);


ALTER TABLE bikesharing.person OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.petugas (
    ktp character varying(20) NOT NULL,
    gaji real NOT NULL
);


ALTER TABLE bikesharing.petugas OWNER TO postgres;

--
-- Name: sepeda; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.sepeda (
    nomor character varying(10) NOT NULL,
    merk character varying(10) NOT NULL,
    jenis character varying(50) NOT NULL,
    status boolean NOT NULL,
    id_stasiun character varying(10) NOT NULL,
    no_kartu_penyumbang character varying(20) NOT NULL
);


ALTER TABLE bikesharing.sepeda OWNER TO postgres;

--
-- Name: stasiun; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.stasiun (
    id_stasiun character varying(10) NOT NULL,
    alamat text NOT NULL,
    lat real,
    long real,
    nama character varying(50) NOT NULL
);


ALTER TABLE bikesharing.stasiun OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.transaksi (
    no_kartu_anggota character varying(10) NOT NULL,
    date_time timestamp without time zone NOT NULL,
    jenis character varying(20) NOT NULL,
    nominal real NOT NULL
);


ALTER TABLE bikesharing.transaksi OWNER TO postgres;

--
-- Name: transaksi_khusus_peminjaman; Type: TABLE; Schema: bikesharing; Owner: db2018044
--

CREATE TABLE bikesharing.transaksi_khusus_peminjaman (
    no_kartu_anggota character varying(10) NOT NULL,
    date_time timestamp without time zone NOT NULL,
    no_kartu_peminjam character varying(10) NOT NULL,
    datetime_pinjam timestamp without time zone NOT NULL,
    no_sepeda character varying(10) NOT NULL,
    id_stasiun character varying(10) NOT NULL
);


ALTER TABLE bikesharing.transaksi_khusus_peminjaman OWNER TO db2018044;

--
-- Name: voucher; Type: TABLE; Schema: bikesharing; Owner: postgres
--

CREATE TABLE bikesharing.voucher (
    id_voucher character varying(10) NOT NULL,
    nama character varying(255) NOT NULL,
    kategori character varying(255) NOT NULL,
    nilai_poin real NOT NULL,
    deskripsi text,
    no_kartu_anggota character varying(10) NOT NULL
);


ALTER TABLE bikesharing.voucher OWNER TO postgres;

--
-- Data for Name: acara; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.acara (id_acara, judul, deskripsi, tgl_mulai, tgl_akhir, is_free) FROM stdin;
\.
COPY bikesharing.acara (id_acara, judul, deskripsi, tgl_mulai, tgl_akhir, is_free) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: acara_stasiun; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.acara_stasiun (id_stasiun, id_acara) FROM stdin;
\.
COPY bikesharing.acara_stasiun (id_stasiun, id_acara) FROM '$$PATH$$/2888.dat';

--
-- Data for Name: anggota; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.anggota (no_kartu, saldo, points, ktp) FROM stdin;
\.
COPY bikesharing.anggota (no_kartu, saldo, points, ktp) FROM '$$PATH$$/2890.dat';

--
-- Data for Name: laporan; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.laporan (id_laporan, no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun, status) FROM stdin;
\.
COPY bikesharing.laporan (id_laporan, no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun, status) FROM '$$PATH$$/2895.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.peminjaman (no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun, datetime_kembali, biaya, denda) FROM stdin;
\.
COPY bikesharing.peminjaman (no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun, datetime_kembali, biaya, denda) FROM '$$PATH$$/2894.dat';

--
-- Data for Name: penugasan; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.penugasan (ktp, start_datetime, id_stasiun, end_datetime) FROM stdin;
\.
COPY bikesharing.penugasan (ktp, start_datetime, id_stasiun, end_datetime) FROM '$$PATH$$/2893.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.person (ktp, email, nama, alamat, tgl_lahir, no_telp) FROM stdin;
\.
COPY bikesharing.person (ktp, email, nama, alamat, tgl_lahir, no_telp) FROM '$$PATH$$/2889.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.petugas (ktp, gaji) FROM stdin;
\.
COPY bikesharing.petugas (ktp, gaji) FROM '$$PATH$$/2892.dat';

--
-- Data for Name: sepeda; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.sepeda (nomor, merk, jenis, status, id_stasiun, no_kartu_penyumbang) FROM stdin;
\.
COPY bikesharing.sepeda (nomor, merk, jenis, status, id_stasiun, no_kartu_penyumbang) FROM '$$PATH$$/2891.dat';

--
-- Data for Name: stasiun; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.stasiun (id_stasiun, alamat, lat, long, nama) FROM stdin;
\.
COPY bikesharing.stasiun (id_stasiun, alamat, lat, long, nama) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.transaksi (no_kartu_anggota, date_time, jenis, nominal) FROM stdin;
\.
COPY bikesharing.transaksi (no_kartu_anggota, date_time, jenis, nominal) FROM '$$PATH$$/2896.dat';

--
-- Data for Name: transaksi_khusus_peminjaman; Type: TABLE DATA; Schema: bikesharing; Owner: db2018044
--

COPY bikesharing.transaksi_khusus_peminjaman (no_kartu_anggota, date_time, no_kartu_peminjam, datetime_pinjam, no_sepeda, id_stasiun) FROM stdin;
\.
COPY bikesharing.transaksi_khusus_peminjaman (no_kartu_anggota, date_time, no_kartu_peminjam, datetime_pinjam, no_sepeda, id_stasiun) FROM '$$PATH$$/2898.dat';

--
-- Data for Name: voucher; Type: TABLE DATA; Schema: bikesharing; Owner: postgres
--

COPY bikesharing.voucher (id_voucher, nama, kategori, nilai_poin, deskripsi, no_kartu_anggota) FROM stdin;
\.
COPY bikesharing.voucher (id_voucher, nama, kategori, nilai_poin, deskripsi, no_kartu_anggota) FROM '$$PATH$$/2897.dat';

--
-- Name: acara acara_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.acara
    ADD CONSTRAINT acara_pkey PRIMARY KEY (id_acara);


--
-- Name: acara_stasiun acara_stasiun_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.acara_stasiun
    ADD CONSTRAINT acara_stasiun_pkey PRIMARY KEY (id_stasiun, id_acara);


--
-- Name: anggota anggota_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.anggota
    ADD CONSTRAINT anggota_pkey PRIMARY KEY (no_kartu);


--
-- Name: laporan laporan_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.laporan
    ADD CONSTRAINT laporan_pkey PRIMARY KEY (id_laporan, no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun);


--
-- Name: penugasan penugasan_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.penugasan
    ADD CONSTRAINT penugasan_pkey PRIMARY KEY (ktp, start_datetime, id_stasiun);


--
-- Name: person person_email_key; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.person
    ADD CONSTRAINT person_email_key UNIQUE (email);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (ktp);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (ktp);


--
-- Name: sepeda sepeda_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.sepeda
    ADD CONSTRAINT sepeda_pkey PRIMARY KEY (nomor);


--
-- Name: stasiun stasiun_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.stasiun
    ADD CONSTRAINT stasiun_pkey PRIMARY KEY (id_stasiun);


--
-- Name: transaksi_khusus_peminjaman transaksi_khusus_peminjaman_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: db2018044
--

ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman
    ADD CONSTRAINT transaksi_khusus_peminjaman_pkey PRIMARY KEY (no_kartu_anggota, date_time);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (no_kartu_anggota, date_time);


--
-- Name: voucher voucher_pkey; Type: CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.voucher
    ADD CONSTRAINT voucher_pkey PRIMARY KEY (id_voucher);


--
-- Name: acara_stasiun acara_stasiun_id_acara_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.acara_stasiun
    ADD CONSTRAINT acara_stasiun_id_acara_fkey FOREIGN KEY (id_acara) REFERENCES bikesharing.acara(id_acara) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acara_stasiun acara_stasiun_id_stasiun_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.acara_stasiun
    ADD CONSTRAINT acara_stasiun_id_stasiun_fkey FOREIGN KEY (id_stasiun) REFERENCES bikesharing.stasiun(id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: anggota anggota_ktp_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.anggota
    ADD CONSTRAINT anggota_ktp_fkey FOREIGN KEY (ktp) REFERENCES bikesharing.person(ktp) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: laporan laporan_no_kartu_anggota_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.laporan
    ADD CONSTRAINT laporan_no_kartu_anggota_fkey FOREIGN KEY (no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun) REFERENCES bikesharing.peminjaman(no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peminjaman peminjaman_id_stasiun_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.peminjaman
    ADD CONSTRAINT peminjaman_id_stasiun_fkey FOREIGN KEY (id_stasiun) REFERENCES bikesharing.stasiun(id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peminjaman peminjaman_no_kartu_anggota_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.peminjaman
    ADD CONSTRAINT peminjaman_no_kartu_anggota_fkey FOREIGN KEY (no_kartu_anggota) REFERENCES bikesharing.anggota(no_kartu) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peminjaman peminjaman_nomor_sepeda_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.peminjaman
    ADD CONSTRAINT peminjaman_nomor_sepeda_fkey FOREIGN KEY (nomor_sepeda) REFERENCES bikesharing.sepeda(nomor) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: penugasan penugasan_id_stasiun_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.penugasan
    ADD CONSTRAINT penugasan_id_stasiun_fkey FOREIGN KEY (id_stasiun) REFERENCES bikesharing.stasiun(id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: penugasan penugasan_ktp_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.penugasan
    ADD CONSTRAINT penugasan_ktp_fkey FOREIGN KEY (ktp) REFERENCES bikesharing.petugas(ktp) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: petugas petugas_ktp_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.petugas
    ADD CONSTRAINT petugas_ktp_fkey FOREIGN KEY (ktp) REFERENCES bikesharing.person(ktp) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sepeda sepeda_id_stasiun_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.sepeda
    ADD CONSTRAINT sepeda_id_stasiun_fkey FOREIGN KEY (id_stasiun) REFERENCES bikesharing.stasiun(id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sepeda sepeda_no_kartu_penyumbang_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.sepeda
    ADD CONSTRAINT sepeda_no_kartu_penyumbang_fkey FOREIGN KEY (no_kartu_penyumbang) REFERENCES bikesharing.anggota(no_kartu) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaksi_khusus_peminjaman transaksi_khusus_peminjaman_no_kartu_anggota_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: db2018044
--

ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman
    ADD CONSTRAINT transaksi_khusus_peminjaman_no_kartu_anggota_fkey FOREIGN KEY (no_kartu_anggota, date_time) REFERENCES bikesharing.transaksi(no_kartu_anggota, date_time) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaksi_khusus_peminjaman transaksi_khusus_peminjaman_no_kartu_peminjam_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: db2018044
--

ALTER TABLE ONLY bikesharing.transaksi_khusus_peminjaman
    ADD CONSTRAINT transaksi_khusus_peminjaman_no_kartu_peminjam_fkey FOREIGN KEY (no_kartu_peminjam, datetime_pinjam, no_sepeda, id_stasiun) REFERENCES bikesharing.peminjaman(no_kartu_anggota, datetime_pinjam, nomor_sepeda, id_stasiun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transaksi transaksi_no_kartu_anggota_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.transaksi
    ADD CONSTRAINT transaksi_no_kartu_anggota_fkey FOREIGN KEY (no_kartu_anggota) REFERENCES bikesharing.anggota(no_kartu);


--
-- Name: voucher voucher_no_kartu_anggota_fkey; Type: FK CONSTRAINT; Schema: bikesharing; Owner: postgres
--

ALTER TABLE ONLY bikesharing.voucher
    ADD CONSTRAINT voucher_no_kartu_anggota_fkey FOREIGN KEY (no_kartu_anggota) REFERENCES bikesharing.anggota(no_kartu) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

